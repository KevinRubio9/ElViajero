using UnityEngine;

public class Damage : MonoBehaviour
{
    [SerializeField] public int damage = 10;

    private void OnCollisionEnter(Collision collision)
    {
        GameObject target = collision.gameObject;

        // Si el objeto tiene CharacterController (el Player)
        CharacterController controller = target.GetComponent<CharacterController>();
        if (controller != null)
        {
            LifeController life = target.GetComponent<LifeController>();
            if (life != null)
            {
                life.TakeDamage(damage);
                Debug.Log($"{gameObject.name} hizo {damage} de da�o al Player ({target.name})");
            }
            return;
        }

        //  Si el objeto tiene LifeController (otro enemigo o destructible)
        LifeController otherLife = target.GetComponent<LifeController>();
        if (otherLife != null)
        {
            otherLife.TakeDamage(damage);
            Debug.Log($"{gameObject.name} hizo {damage} de da�o a {target.name}");
        }
    }
}
